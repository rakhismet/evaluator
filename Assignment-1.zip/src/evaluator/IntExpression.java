package evaluator;

public interface IntExpression {

    public int getValue();

}
