package evaluator;

public class DivideByZeroException extends ArithmeticException {

}
